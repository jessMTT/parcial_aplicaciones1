package com.example.parcial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nombre, password;
    Button btnIngresar = findViewById(R.id.btnIngresar);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        nombre = findViewById(R.id.usuario);
        password = findViewById(R.id.contraseña);

        String texto1 = nombre.getText().toString();
        String texto2 = password.getText().toString();
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (texto1.isEmpty() || texto2.isEmpty()){
                    nombre.setText("rellene los datos");
                    password.setText("rellene los datos");
                } else {
                    if(texto1.equals("uac123") && texto2.equals("12345678")){
                        Intent i = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(i);
                    } else {
                        nombre.setText("datos erroneos");
                        password.setText("datos erroneos");
                    }
                }
            }
        });



    }
}

